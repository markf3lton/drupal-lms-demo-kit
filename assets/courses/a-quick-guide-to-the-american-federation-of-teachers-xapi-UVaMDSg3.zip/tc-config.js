/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://2kx4GcYEshDLp1ArOYaS12ScWuTLTyd6_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "A Quick Guide to the American Federation of Teachers"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": "Did you know that one of the largest teacher unions in the U.S. has shaped education for over a century? Whether you’re a new educator or studying to become one, understanding the American Federation of Teachers (AFT) is key to grasping the broader landscape of education. In this concise course, you&#39;ll discover what the AFT is, why it was founded, and how it continues to influence schools, teachers, and students. Get ready to learn about its rich history, lasting impact, and some surprising facts along the way."
};
